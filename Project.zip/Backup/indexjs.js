vegie_list=['Tomato', 'Potato', 'Cabbage']

function getData(){
	
	vegie_list.forEach(item => {

	const params={
	api_key:"fWeUAVXqIJd6g9Zls7l3AgHQSuLMg7qTwgrR7Irq",
	query:"Raw "+item,
	dataType:["Survey (FNDDS)"],
	pagesize:1,
		}	

	const api_url = `https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${encodeURIComponent(params.api_key)}&query=${encodeURIComponent(params.query)}&dataType=${encodeURIComponent(params.dataType)}&pageSize=${encodeURIComponent(params.pagesize)}`
	fetch(api_url).then((response)=>{
		return response.json();
	}).then((data) => createTable(data, item));

})//for loop ends
}// function ends

function createTable(data, item){
	console.log(data)
	nutriInfo=`<tr>
				<td>
               	${item}
                </td>
               	<td>
               	${data.foods[0].foodNutrients[0].value}
                </td>
                <td>
               	${data.foods[0].foodNutrients[1].value}
                </td>
                <td>
               	${data.foods[0].foodNutrients[2].value}
                </td>
                <td>
               	${data.foods[0].foodNutrients[3].value}
                </td>
              </tr>

	`

	$("#results").append(nutriInfo);
}




