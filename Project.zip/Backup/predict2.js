let model;
(async function () {
    model = await tf.loadLayersModel("http://localhost:81/tfjs-model/model.json");
    $(".progress-bar").hide();
})();

function convertURIToImageData(URI) {
  return new Promise(function(resolve, reject) {
    if (URI == null) return reject();
    var canvas = document.createElement('canvas'),
        context = canvas.getContext('2d'),
        image = new Image();
    image.addEventListener('load', function() {
      canvas.width = image.width;
      canvas.height = image.height;
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      resolve(context.getImageData(0, 0, canvas.width, canvas.height));
    }, false);
    image.src = URI;
  });
}



vegie_list = [];
$("#reset-button").click( function () {

    vegie_list=[];
    $("#prediction-list").empty();

});



$("#predict-button").click( function () {

    Webcam.snap( function(data_uri) {
    convertURIToImageData(data_uri).then(async function(image) {
    let offset = tf.scalar(127.5)
    var tensor = tf.browser.fromPixels(image)
    .resizeNearestNeighbor([224, 224])
    .toFloat()
    .sub(offset)
    .div(offset)
    .reshape([224, 224, 3])
    .expandDims();



// More pre-processing to be added here later

let predictions = await model.predict(tensor).data().then();

let top = Array.from(predictions)
    .map(function (p, i) {
        return {
            probability: p,
            className: LABELS[i]
        };
    }).sort(function (a, b) {
        return b.probability - a.probability;
    }).slice(0, 1);


    
    vegie_list.push(top[0].className)
    console.log(vegie_list)
    $("#prediction-list").empty();
    $("#prediction-list").html(vegie_list +", ");
});
});
});